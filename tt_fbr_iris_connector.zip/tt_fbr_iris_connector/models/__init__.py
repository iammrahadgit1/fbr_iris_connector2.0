from . import res_company
from . import res_partner
# from . import res_config_settings
from . import pos_order
# from . import pos_order_line
from . import product_template
# from . import product_pct_code
from . import pos_config
from . import account_move
from . import account_tax
from . import product_product